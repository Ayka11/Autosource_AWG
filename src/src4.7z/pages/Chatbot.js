import React, { useState, useEffect, useRef } from "react";
import "./chatbot.css"; // Ensure this path is correct

const Chatbot = () => {
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState(() => {
    // Retrieve chat history from sessionStorage, or set to an empty array if not found
    const savedHistory = sessionStorage.getItem("chatHistory");
    return savedHistory ? JSON.parse(savedHistory) : [];
  });
  const chatHistoryRef = useRef(null);

  const makeRequest = async (questions) => {
    try {
      const response = await fetch(
        "https://python-app-779410445796.us-central1.run.app/chat",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${process.env.REACT_APP_VERTEX_API_KEY}`, // Add your API key
          },
          body: JSON.stringify({ input: questions }),
        }
      );

      if (!response.ok) {
        throw new Error("Network response was not ok");
      }

      const data = await response.json();
      return data;
    } catch (error) {
      console.error("Error fetching the response:", error);
      throw error;
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    const questions = input
      .split(/[\n,]+/)
      .map((q) => q.trim())
      .filter(Boolean);

    const newHistory = [];

    try {
      const res = await makeRequest(questions);

      questions.forEach((question, index) => {
        const botResponse = res.response[index];
        newHistory.push({
          question,
          response: botResponse || "I couldn't find an answer to that.",
        });
      });
    } catch (error) {
      console.error("Error fetching the response:", error);
      newHistory.push({
        question: input,
        response: "Sorry, there was an error processing your request.",
      });
    }

    const updatedHistory = [...history, ...newHistory];
    setHistory(updatedHistory);
    sessionStorage.setItem("chatHistory", JSON.stringify(updatedHistory)); // Save to sessionStorage
    setLoading(false);
    setInput("");
  };

  useEffect(() => {
    if (chatHistoryRef.current) {
      chatHistoryRef.current.scrollTop = chatHistoryRef.current.scrollHeight;
    }
  }, [history]);

  const handleKeyPress = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  return (
    <div className="chatbot-container">
      <div className="chatbot-history" ref={chatHistoryRef}>
        {history.map((item, index) => (
          <div key={index} className="chatbot-history-item">
            <div className="chatbot-user-message">
              <p>
                <strong>You:</strong> {item.question}
              </p>
            </div>
            <div className="chatbot-bot-message">
              <p>
                <strong>Chatbot:</strong> {item.response}
              </p>
            </div>
          </div>
        ))}
      </div>

      <form onSubmit={handleSubmit} className="chatbot-form">
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask me anything about AWG or anything else..."
          required
          className="chatbot-input"
          onKeyPress={handleKeyPress}
        />
        <button type="submit" disabled={loading} className="chatbot-button">
          {loading ? "Loading..." : "Send"}
        </button>
      </form>
    </div>
  );
};

export default Chatbot;
