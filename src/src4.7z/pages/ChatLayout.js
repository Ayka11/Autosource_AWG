// ChatLayout.js
import React, { useState, useEffect, useRef } from "react";
import Chatbot from "./Chatbot"; // Ensure this path is correct based on your project structure

const ChatLayout = () => {
  const [isMobile, setIsMobile] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false); // State to manage chat visibility
  const chatWindowRef = useRef(null); // Create a ref for the chat window

  // Check if the screen is mobile or desktop
  useEffect(() => {
    const checkMobileScreen = () => {
      setIsMobile(window.innerWidth <= 768);
    };

    window.addEventListener("resize", checkMobileScreen);
    checkMobileScreen();

    return () => window.removeEventListener("resize", checkMobileScreen);
  }, []);

  // Close chat window if clicked outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        chatWindowRef.current &&
        !chatWindowRef.current.contains(event.target) &&
        isChatOpen
      ) {
        setIsChatOpen(false); // Close the chat if clicked outside
      }
    };

    document.addEventListener("mousedown", handleClickOutside);

    return () => {
      document.removeEventListener("mousedown", handleClickOutside); // Cleanup event listener
    };
  }, [isChatOpen]);

  const pageStyles = {
    chatIcon: {
      position: "fixed",
      bottom: "0px",
      right: "10px",
      width: "40px",
      height: "40px",
      backgroundColor: "#007BFF",
      color: "#fff",
      borderRadius: "50%",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      cursor: "pointer",
      boxShadow: "0 4px 8px rgba(0,0,0,0.2)",
    },
    chatWindow: {
      position: "fixed",
      bottom: "0px",
      right: "10px",
      width: "300px",
      height: "500px",
      border: "1px solid #007BFF",
      borderRadius: "8px",
      backgroundColor: "#fff",
      display: isChatOpen ? "block" : "none",
      boxShadow: "0 4px 8px rgba(0,0,0,0.2)",
      overflow: "hidden",
    },
    chatHeader: {
      backgroundColor: "#007BFF",
      color: "#fff",
      padding: "10px",
      borderTopLeftRadius: "8px",
      borderTopRightRadius: "8px",
    },
  };

  const toggleChat = () => {
    setIsChatOpen(!isChatOpen);
  };

  return (
    <>
      {/* Chat Icon */}
      <div style={pageStyles.chatIcon} onClick={toggleChat}>
        💬
      </div>

      {/* Chat Window with Chatbot */}
      <div style={pageStyles.chatWindow} ref={chatWindowRef}>
        <div style={pageStyles.chatHeader}>Chat with Us</div>
        <Chatbot /> {/* Integrate Chatbot component */}
      </div>
    </>
  );
};

export default ChatLayout;
